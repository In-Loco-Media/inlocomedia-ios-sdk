//
//  UBEGADInterstitialAdapter.h
//  InLocoMedia IOS Adapters
//
//  Created by Ubee on 8/12/14.
//  Copyright (c) 2014 Ubee. All rights reserved.
//

#import <Foundation/Foundation.h>
@import GoogleMobileAds;

@interface UBEGADInterstitialAdapter : NSObject <GADCustomEventInterstitial>

@end
