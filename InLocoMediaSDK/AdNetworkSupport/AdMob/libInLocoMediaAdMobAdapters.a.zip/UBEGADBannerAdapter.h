//
//  UBEGADBannerAdapter.h
//  InLocoMedia IOS Adapters
//
//  Created by Ubee on 8/8/14.
//  Copyright (c) 2014 Ubee. All rights reserved.
//

#import <Foundation/Foundation.h>
@import GoogleMobileAds;

@interface UBEGADBannerAdapter : NSObject <GADCustomEventBanner>

@end
