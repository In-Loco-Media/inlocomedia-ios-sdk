//
//  ILMOptions.h
//  InLocoMedia-iOS-SDK-Core
//
//  Created by Dicksson Oliveira on 12/12/17.
//  Copyright © 2017 InLocoMedia. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ILMOptions : NSObject

@end
